﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AENM_BUSINESS_SOLUTION
{
    public partial class FRM_MAIN : Form
    {

        int distance = 0;
        Form generalform = new Form();

        public FRM_MAIN()
        {
            InitializeComponent();
        }

        private void FRM_MAIN_Load(object sender, EventArgs e)
        {
            splitContainer1.SplitterDistance = distance;
           
        }

        //Self Define Method
        private void loadForm(Form _generalForm, Form newForm)
        {
            this.splitContainer1.Panel2.Controls.Clear();
            _generalForm.Dispose();
            _generalForm.Close();
            _generalForm = newForm;
            _generalForm.TopLevel = false;
            _generalForm.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
            this.splitContainer1.Panel2.Controls.Add(_generalForm);
            splitContainer1.SplitterDistance = 0;
            _generalForm.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (distance == 0)
            {
                splitContainer1.SplitterDistance = 220;
                distance = 220;
            }
            else
            {
                splitContainer1.SplitterDistance = 0;
                distance = 0;
            }
             
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            loadForm(generalform, new FRM_SALES_QUOTATION());
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            loadForm(generalform, new FRM_SALES_INVOICE());
        }
    }
}
