﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AENM_BUSINESS_SOLUTION
{
    public partial class FRM_SALES_QUOTATION : Form
    {
        public FRM_SALES_QUOTATION()
        {
            InitializeComponent();
        }

        private DataTable CreateDatable()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Customer");
            dataTable.Columns.Add("Address");
            dataTable.Columns.Add("Mobile");
            dataTable.Columns.Add("Phone");
            dataTable.Columns.Add("Email");
            dataTable.Columns.Add("Invoice");
            dataTable.Columns.Add("Status");

            dataTable.Rows.Add("Bill Wagner","Bacoor","09070506974","43-49-80","@gmail.com","INV-0001","Invoiced");
            dataTable.Rows.Add("Scott Hanselman", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "INV-0002","Invoiced");
            dataTable.Rows.Add("Dino Esposito Wagner", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "", "Pending");
            dataTable.Rows.Add("Jon Galloway", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "","Accepted");
            dataTable.Rows.Add("Robert Sheldon", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "","Rejected");
            return dataTable;
        }

        private void FRM_SALES_QUOTATION_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = CreateDatable();
            
        }

        private void cREATEQUOTATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FRM_SALES_QUOTATION_CREATE fRM_SALES_QUOTATION_CREATE = new FRM_SALES_QUOTATION_CREATE();
            fRM_SALES_QUOTATION_CREATE.ShowDialog();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FRM_SALES_INVOICE_CREATE fRM_SALES_INVOICE_CREATE = new FRM_SALES_INVOICE_CREATE();
            fRM_SALES_INVOICE_CREATE.ShowDialog();
        }

        private void cREATEINVOICEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FRM_SALES_INVOICE_CREATE fRM_SALES_INVOICE_CREATE = new FRM_SALES_INVOICE_CREATE();
            fRM_SALES_INVOICE_CREATE.ShowDialog();
        }
    }
}
