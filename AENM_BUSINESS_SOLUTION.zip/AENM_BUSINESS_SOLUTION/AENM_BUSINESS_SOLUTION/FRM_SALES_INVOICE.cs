﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AENM_BUSINESS_SOLUTION
{
    public partial class FRM_SALES_INVOICE : Form
    {
        public FRM_SALES_INVOICE()
        {
            InitializeComponent();
        }

        private DataTable CreateDatable()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("InvoiceNo");
            dataTable.Columns.Add("Customer");
            dataTable.Columns.Add("Address");
            dataTable.Columns.Add("Mobile");
            dataTable.Columns.Add("Phone");
            dataTable.Columns.Add("Email");
            dataTable.Columns.Add("Quotation");
            dataTable.Columns.Add("Total");
            dataTable.Columns.Add("Paid");
            dataTable.Columns.Add("Balance");
            dataTable.Columns.Add("Due");
            dataTable.Columns.Add("Status");

            dataTable.Rows.Add("INV-001","Bill Wagner", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "QT-0001","12000","6500","5500","2019-06-30", "OPEN");
            dataTable.Rows.Add("INV-002","Scott Hanselman", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "QT-0002", "12000", "6500", "5500", "2019-06-30", "TO EXPIRED");
            dataTable.Rows.Add("INV-003","Dino Esposito Wagner", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "QT-0003", "12000", "6500", "5500", "2019-06-30", "EXPIRED");
            dataTable.Rows.Add("INV-004","Jon Galloway", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "QT-0003", "12000", "6500", "5500", "2019-06-30","PAID");
            dataTable.Rows.Add("INV-005","Robert Sheldon", "Bacoor", "09070506974", "43-49-80", "@gmail.com", "QT-0003", "12000", "6500", "5500", "2019-06-30","PAID");
            return dataTable;
        }

        private void FRM_SALES_INVOICE_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = CreateDatable();
        }

        private void cREATEINVOICEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FRM_SALES_INVOICE_CREATE fRM_SALES_INVOICE_CREATE = new FRM_SALES_INVOICE_CREATE();
            fRM_SALES_INVOICE_CREATE.ShowDialog();
        }
    }
}
