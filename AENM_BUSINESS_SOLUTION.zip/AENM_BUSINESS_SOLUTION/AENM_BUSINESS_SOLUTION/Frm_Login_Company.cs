﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AENM_BUSINESS_SOLUTION
{
    public partial class Frm_Login_Company : Form
    {
        public Frm_Login_Company()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FRM_Login_User fRM_Login_User = new FRM_Login_User();
            fRM_Login_User.ShowDialog();
            this.Hide();
        }
    }
}
