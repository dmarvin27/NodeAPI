﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AENM_BUSINESS_SOLUTION
{
    public partial class FRM_Login_User : Form
    {
        public FRM_Login_User()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FRM_MAIN fRM_MAIN = new FRM_MAIN();
            fRM_MAIN.Show();
            this.Hide();
        }
    }
}
